({
	addNew : function(component, event, helper){
        component.getEvent("leadAdd").fire();     
    },
})
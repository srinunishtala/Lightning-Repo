({
	collectFirstStep : function(component, event, helper) {
        
		console.log('ttttttt');
        
		var expNameVar = event.getParam("expName");
        
        console.log(expNameVar);
		
	},
    
    
})
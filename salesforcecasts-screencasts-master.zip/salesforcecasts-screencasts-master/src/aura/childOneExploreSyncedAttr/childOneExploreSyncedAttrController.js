({
	updateMessage : function(component, event, helper) {
		component.set("v.message", "This is updated in childOneSyncedAttr");
	}
})
({
	doInit: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
    
    addNewLead: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
})
({
    commonFunc : function(component, event){	    
        
        component.set("v.message", event.getSource().get("v.label"));
    }
})
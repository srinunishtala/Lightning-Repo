({
	
    addNewRow: function(component, event, helper) {
        helper.createObjectData(component, event);
    },
})